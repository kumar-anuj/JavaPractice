package data.processor.strategy;

import java.util.List;

public interface dataProccessorStrategy<T> {
	public List<T> processData(List<T> items);
}
