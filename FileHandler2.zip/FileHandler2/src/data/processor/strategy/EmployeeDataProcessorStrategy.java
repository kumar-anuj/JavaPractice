package data.processor.strategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import data.currency.Currency;
import data.model.Employee;

public class EmployeeDataProcessorStrategy implements dataProccessorStrategy<Employee>{

	Properties properties;
	
	public EmployeeDataProcessorStrategy(Properties properties) {
		super();
		this.properties = properties;
	}



	@Override
	public List<Employee> processData(List<Employee> items) {

		Map<String, Double> employeeSalaries = new TreeMap<String, Double>();
		Map<String, Integer> employeeOccurrences = new HashMap<String, Integer>();
		
		for(Employee employee : items){
			
			String cntryGndrKey = String.join(",", employee.getCountry().length() != 0  ? employee.getCountry() : employee.getCity(), employee.getGender());
			
			if(employeeSalaries.containsKey(cntryGndrKey)){
				employeeSalaries.put(cntryGndrKey, employeeSalaries.get(cntryGndrKey) + Currency.getConvertedIncome(employee.getIncome(), employee.getCurrency(), Currency.valueOf(properties.getProperty("desiredCurrencyType"))));
			} else {
				employeeSalaries.put(cntryGndrKey, Currency.getConvertedIncome(employee.getIncome(), employee.getCurrency(), Currency.valueOf(properties.getProperty("desiredCurrencyType"))));
			}
			
			if(employeeOccurrences.containsKey(cntryGndrKey)){
				employeeOccurrences.put(cntryGndrKey, employeeOccurrences.get(cntryGndrKey) + 1);
			} else{
				employeeOccurrences.put(cntryGndrKey, 1);
			}
		}
		
		return enrichData(employeeSalaries, employeeOccurrences);
	}
	
	
	public List<Employee> enrichData(Map<String, Double> employeeSalaries, Map<String, Integer> employeeOccurrences){
		
		
		List<Employee> employees = new ArrayList<Employee>();
		
		for(String cntryGndrKey : employeeSalaries.keySet()){
			
			String[] employeeData = cntryGndrKey.split(",");
		
			Employee employee = new Employee();
			employee.setCountry(employeeData[0]);
			employee.setGender(employeeData[1]);
			
			Double averageIncome = employeeSalaries.get(cntryGndrKey)/employeeOccurrences.get(cntryGndrKey);
			
			employee.setIncome(averageIncome);
			employees.add(employee);
		}
		
		return employees;
	}

}
