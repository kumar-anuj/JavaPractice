package data.reader;

import java.util.List;

public interface DataReader<T> {

	public List<T> readDat(Object inputResource);
	
}
