package data.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import data.mapper.EmployeeDataMapperUtil;
import data.model.Employee;

public class CSVFileDataReader implements DataReader<Employee> {

	@Override
	public List<Employee> readDat(Object inputResource) {
		
		List<Employee> employeeData = new ArrayList<Employee>();
		
		try(BufferedReader br = new BufferedReader(new FileReader(new File((String)inputResource)))){
			String line = br.readLine();
			while((line = br.readLine()) != null){
				if(line.length()==0)
					continue;
				employeeData.add(EmployeeDataMapperUtil.generateEmploye(line.split(",")));
			}
			
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employeeData;
	}

	
	
}
