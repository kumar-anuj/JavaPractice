package data.writer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import data.mapper.EmployeeDataMapperUtil;
import data.model.Employee;

public class CSVFileDataWriter implements DataWriter<Employee>{

	Properties properties;
	
	public CSVFileDataWriter(Properties properties) {
		this.properties = properties;
	}

	@Override
	public void writeData(List<Employee> items, Object outputSource) {
		
			try(BufferedWriter bw = new BufferedWriter(new FileWriter(new File((String)outputSource)))) {

				String header = String.join(",", "Country / City Name","Gender","Average Income ("+properties.getProperty("desiredCurrencyType")+")") + System.lineSeparator();
				bw.write(header);
				
				for(Employee employee : items) {
				bw.write(System.lineSeparator());
				bw.write(EmployeeDataMapperUtil.generateRow(employee));
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
