package data.writer;

import java.util.List;

public interface DataWriter<T> {
	public void writeData(List<T> items, Object outputSource);	
}
