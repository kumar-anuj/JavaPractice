package data.currency;

public enum Currency {
		
	INR(1.00),USD(1.00),HKD(1.00),SGP(0.74), GBP(1.28);
	
	private double dollarValue;
	
	public double getDollarValue() {
		return dollarValue;
	}

	private Currency(double dollarValue){
		this.dollarValue=dollarValue;
	}

	public static double getConvertedIncome(double amount, Currency currencyType, Currency desiredCurrencyType){
			return (amount * (currencyType.getDollarValue()/desiredCurrencyType.getDollarValue()));
	}

}
