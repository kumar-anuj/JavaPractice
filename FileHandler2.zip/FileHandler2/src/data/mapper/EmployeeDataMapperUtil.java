package data.mapper;

import data.currency.Currency;
import data.model.Employee;

public class EmployeeDataMapperUtil {

	
	public static Employee generateEmploye(String[] rowData){
		
		Employee employee = new Employee();
		
		employee.setCity(rowData[0]);
		employee.setCountry(rowData[1]);
		employee.setGender(rowData[2]);
		employee.setCurrency(Currency.valueOf(rowData[3]));
		employee.setIncome(Double.valueOf(rowData[4]));
		
		return employee;
	}
	
	public static String generateRow(Employee employee){
		return String.join(",", employee.getCountry().length() != 0 ? employee.getCountry() : employee.getCity(), employee.getGender(), employee.getIncome().toString()) + System.lineSeparator();
		
	}
}
