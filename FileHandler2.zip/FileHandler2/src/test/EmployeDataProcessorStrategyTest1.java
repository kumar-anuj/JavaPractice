package test;

import data.currency.Currency;
import data.model.Employee;
import data.processor.strategy.EmployeeDataProcessorStrategy;
import data.processor.strategy.dataProccessorStrategy;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


public class EmployeDataProcessorStrategyTest1 {

    @Test
    public void testProcessData(){

        Employee e1 = new Employee();
        e1.setCountry("HONKONG");
        e1.setCurrency(Currency.valueOf("HKD"));
        e1.setGender("F");
        e1.setIncome(50000);

        Employee e2 = new Employee();
        e2.setCountry("IND");
        e2.setCurrency(Currency.valueOf("INR"));
        e2.setGender("M");
        e2.setIncome(40000);

        Employee e3 = new Employee();
        e3.setCountry("HONKONG");
        e3.setCurrency(Currency.valueOf("HKD"));
        e3.setGender("F");
        e3.setIncome(30000);

        Employee e4 = new Employee();
        e4.setCountry("IND");
        e4.setCurrency(Currency.valueOf("INR"));
        e4.setGender("F");
        e4.setIncome(50000);

        List<Employee> employees = new ArrayList<Employee>();
        employees.add(e1);
        employees.add(e2);
        employees.add(e3);
        employees.add(e4);

        Properties properties = new Properties();
        properties.setProperty("desiredCurrencyType", "USD");

        dataProccessorStrategy<Employee> strategy = new EmployeeDataProcessorStrategy(properties);
        List<Employee> employeeData = strategy.processData(employees);

        Employee employee = employeeData.get(0);

        Assert.assertEquals("HONKONG", employee.getCountry());
        Assert.assertEquals("F", employee.getGender());
        Assert.assertEquals(new Double(40000.00), employee.getIncome());

    }
}
