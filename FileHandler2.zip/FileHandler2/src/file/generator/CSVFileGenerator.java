package file.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Properties;

import data.model.Employee;
import data.processor.strategy.EmployeeDataProcessorStrategy;
import data.processor.strategy.dataProccessorStrategy;
import data.reader.DataReader;
import data.writer.DataWriter;
import factory.ReaderFactory;
import factory.WriterFactory;

public class CSVFileGenerator {

	public static void generateCSVFile(DataReader reader, dataProccessorStrategy startegy, DataWriter writer, String inputResource, String outputSource){
		List<Employee> employees = reader.readDat(inputResource);
		List<Employee> aggregatedEmployees = startegy.processData(employees);
		writer.writeData(aggregatedEmployees, outputSource);
	}
	
	public static void main(String[] args) {
		
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(new File("config.properties"));
			Properties properties = new Properties();
			properties.load(inputStream);
			
			DataReader<Employee> reader = ReaderFactory.newReader("CSV");
			dataProccessorStrategy<Employee> strategy = new EmployeeDataProcessorStrategy(properties);
			DataWriter<Employee> writer = WriterFactory.newWriter("CSV", properties);
			
			generateCSVFile(reader, strategy, writer, properties.getProperty("inputFile"), properties.getProperty("outputFile"));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
}
