package factory;

import data.reader.CSVFileDataReader;
import data.reader.DataReader;

public class ReaderFactory {

	public static DataReader newReader(String sourceType){
		
		switch(sourceType){
		case "CSV":
		return new CSVFileDataReader();
		default : 
			return null;
		}
	}
	
}
