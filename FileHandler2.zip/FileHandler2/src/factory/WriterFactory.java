package factory;

import java.util.Properties;

import data.reader.CSVFileDataReader;
import data.reader.DataReader;
import data.writer.CSVFileDataWriter;
import data.writer.DataWriter;

public class WriterFactory {

	public static DataWriter newWriter(String sourceType, Properties properties){
		
		switch(sourceType){
		case "CSV":
		return new CSVFileDataWriter(properties);
		default : 
			return null;
		}
	}
	
}
